exports.holeStory = (req, res) => {
    res.json([
        {
            id:1,
            text:(Era uma vez uma menina, que vivia numa pequena vila perto de uma floresta mágica, era adorada por todos,
                 mas principalmente pela sua avó. Certo dia, a avó ofereceu-lhe um capucho vermelho por ser tão doce e bondosa. 
                 A menina gostou tanto do presente que nunca mais o tirou e passou a ser chamada de Capuchinho Vermelho.
                  \nUm belo dia, Capuchinho Vermelho acordou com uma sms da sua mãe, que lhe pedia que levasse a cesta que tinha preparado para casa de sua avó, que estava muito doente.
                  \nCapuchinho Vermelho respondeu:
                  \n\n\n\n- 1. Bom dia mãe, como está a avozinha? Há mais alguma coisa para levar?
                  \n- 2. Bom dia mãe, não vou levar isso, é muito longe, a velha que venha buscar.
                  \n- 3. Viu a mensagem mas nem sequer se levantou.),
            options:[1,2,3]

        },
        {
            id:11,
            text:(- Ela está bem, só não está em condições de ir buscar a cesta, pois está de cama e seria ótimo ires lá cuidar dela.
                Capuchinho levantou-se, calçou os seus sapatinhos e chamou um Uber para a casa da sua avózinha.
            Quando o motorista chegou ela ficou muito surpreendida por este ser um lobo, de olhos grandes e de focinho vermelho.
            O lobo dirigiu-se ao Capuchinho e perguntou-lhe:
            -Bom dia minha senhora, Vai para onde?
            -Vou para o fim da vila. - Respondeu Capuchinho.
            Começaram a sua viagem e tudo corria bem, ela ia apreciando a paisagem enquanto ouvia Cardi B.
            De repente, ouviu-se um grande estrondo, o carro passou por buraco e o pneu furou, deixando os dois a pé, 
            numa estrada vazia e sem rede. 
            Enquanto esperaram que alguém passasse e os ajudasse o lobo começou a ficar com fome e perguntou:
            -Olhe, estamos aqui presos e a senhora está com uma cesta de comida na mão, não me quer dar alguma coisinha dessa cesta não?
            Capuchinho respondeu:
            - Mas é claro que não, isto é para a minha avozinha que está doente!!
            O lobo cheio de fome, vai na direção de Capuchinho e diz:
            -Tens que me dar algo para comer se não vou ter que ser agressivo.
            Capuchinho então:
            - 1. Dá um soco na boca do lobo e corre em direção à floresta.
            - 2. Entrega-lhe o cesto com a comida e corre para a floresta.
            - 3. Simplesmente corre em direção à floresta.
            )
            options:[1,2,3]
        },
        {
            id:12,
            text:(- Estás maluca só pode!? Eu sou tua mãe, levanta esse rabo e põe-te a andar antes que vá aí dar-te na cabeça.
            Capuchinho levantou-se, calçou os seus sapatinhos e chamou um Uber para a casa da sua avózinha.
            Quando o motorista chegou ela ficou muito surpreendida por este ser um lobo, de olhos grandes e de focinho vermelho.
            O lobo dirigiu-se ao Capuchinho e perguntou-lhe:
            -Bom dia minha senhora, Vai para onde?
            -Vou para o fim da vila. - Respondeu Capuchinho.
            Começaram a sua viagem e tudo corria bem, ela ia apreciando a paisagem enquanto ouvia Cardi B.
            De repente, ouviu-se um grande estrondo, o carro passou por buraco e o pneu furou, deixando os dois a pé, 
            numa estrada vazia e sem rede. 
            Enquanto esperaram que alguém passasse e os ajudasse o lobo começou a ficar com fome e perguntou:
            -Olhe, estamos aqui presos e a senhora está com uma cesta de comida na mão, não me quer dar alguma coisinha dessa cesta não?
            Capuchinho respondeu:
            - Mas é claro que não, isto é para a minha avozinha que está doente!!
            O lobo cheio de fome, vai na direção de Capuchinho e diz:
            -Tens que me dar algo para comer se não vou ter que ser agressivo.
            Capuchinho então:
            - 1. Dá um soco na boca do lobo e corre em direção à floresta.
            - 2. Entrega-lhe o cesto com a comida e corre para a floresta.
            - 3. Simplesmente corre em direção à floresta.
            )
            options:[1,2,3]
        },
        {
            id:13,
            text:(- Olha sua preguiçosa já há mais de 2 horas que te mandei ir cuidar da tua avó. Se não te pões a andar vais apanhar uma porrada que vais ficar sem andar praí uns 4 dias. ́
                Capuchinho levantou-se, calçou os seus sapatinhos e chamou um Uber para a casa da sua avózinha.
            Quando o motorista chegou ela ficou muito surpreendida por este ser um lobo, de olhos grandes e de focinho vermelho.
            O lobo dirigiu-se ao Capuchinho e perguntou-lhe:
            -Bom dia minha senhora, Vai para onde?
            -Vou para o fim da vila. - Respondeu Capuchinho.
            Começaram a sua viagem e tudo corria bem, ela ia apreciando a paisagem enquanto ouvia Cardi B.
            De repente, ouviu-se um grande estrondo, o carro passou por buraco e o pneu furou, deixando os dois a pé, 
            numa estrada vazia e sem rede. 
            Enquanto esperaram que alguém passasse e os ajudasse o lobo começou a ficar com fome e perguntou:
            -Olhe, estamos aqui presos e a senhora está com uma cesta de comida na mão, não me quer dar alguma coisinha dessa cesta não?
            Capuchinho respondeu:
            - Mas é claro que não, isto é para a minha avozinha que está doente!!
            O lobo cheio de fome, vai na direção de Capuchinho e diz:
            -Tens que me dar algo para comer se não vou ter que ser agressivo.
            Capuchinho então:
            - 1. Dá um soco na boca do lobo e corre em direção à floresta.
            - 2. Entrega-lhe o cesto com a comida e corre para a floresta.
            - 3. Simplesmente corre em direção à floresta.
            )
            options:[1,2,3]
        },
        {
            id:111 || 121 || 131,
            text:(Ao ouvir as palavras do lobo, Capuchinho enche-se de força e dá um murro no focinho do lobo, que fica vermelho de raiva. 
                 Cheia de medo, a menina começa a fugir para dentro da floresta mas o lobo vai atrás dela. 
                 A perseguição decorre já algum tempo quando Capuchinho começa a ficar desesperada, e decide ir para as profundezas da floresta na esperança de se esconder e despistar o lobo. 
                 Encontra uma espécie de gruta escura, cuja entrada está tapada por alguns arbustos e decide esconder-se lá.
                Se ficar quieta e calada, ele não me descobre - pensou ela.
                Mas o lobo estava furioso e determinado a comer o que havia naquela cesta.
                 Após algum tempo consegue encontrá-la, mas a sua raiva era tanta que acaba por matar Capuchinho.
                Passado alguns dias ninguém sabia nada de Capuchinho e toda a vila andava á sua procura, é então que um caçador a encontra. 
                Desde esse dia, o Caçador, furioso e abalado com a imagem da menina sem vida, vagueia pela floresta à procura do lobo, para se vingar do que foi feito ao Capuchinho Vermelho.
                FIM DO JOGO
                
            )
            options:[]
        },
        {
            id:112 || 122 || 132,
            text:Envergonhada porque já nao tem o cesta, Capuchinho decide fugir para sempre e nunca mais voltar.
            FIM DO JOGO
            )
            options:[]
        },
        {
            id:113 || 123 || 133,
            text:(Após correr por algum tempo pela floresta e certificar-se que está longe do lobo, ela vê um homem ao longe, 
                ao chegar mais perto percebe que é um caçador, então decide começar a gritar por ajuda e ele vem na sua direção.
                - Em que posso ajudar??
                Capuchinho desesperada diz-lhe:
                - Estou a fugir de um lobo maluco que quer a minha comida.
                O caçador pega no seu machado e vai atrás do lobo, mas quando chegam ao local onde ficaram presos, não há sinais do lobo nem do carro, 
                Capuchinho percebe que o lobo foi embora e fica mais descansada, assim pode continuar a sua viagem até casa da avózinha. 
                Antes de partir, agradeçe ao caçador pela sua ajuda e ele diz-lhe:
                Têm cuidado com o caminho e com as pessoas que nele passam. Esta floresta é perigosa. Leva este spray pimenta, 
                pode te ajudar caso te apareça outro anormal.
                E Capuchinho partiu a pé em direção a casa de sua avó.
                No carro, o lobo percebe que Capuchinho deixou o seu telemóvel no banco, então tem uma ideia brilhante, chegar primeiro a casa da avózinha, 
                livrar-se da velha e conseguir a cesta de comida que tanto desejava. 
                Quando chega a casa da avó de Capuchinho, começa a ouvir um barulho muito alto, rapidamente percebe que é o ressonar da senhora, que dorme profundamente. 
                Decide amarrá-la, escondê-la num armário na cave, para que os roncos não se ouçam, vestir as suas roupas e deitar-se na cama a ver Netflix
                 enquanto espera que a Capuchinho chegue.
                Enquanto isso, não muito longe Capuchinho caminha pela floresta, onde vê algumas coisas que pode levar à sua avozinha para a deixar mais feliz:
                - 1. continuar a vasculhar pela floresta (grande chance de encontrar itens e um novo personagem)
                - 2. seguir o caminho para casa da avó
                - 3. comer o cesto de comida.
            )
            options:[1,2,3]
        },
        {
            id:1131 || 1231 || 1331,
            text:(Ao procurar por mais prendas, Capuchinho vai entrando cada vez mais dentro da floresta, até que encontra uma pequena vila de gnomos, com casas pequeninas e muito coloridas. Ela percebe que deve estar já muito longe do seu caminho, e decide perguntar por direções.

                -Olá, alguém me sabe dizer onde fica a estrada para o fim da vila principal? Eu estava a andar na floresta e acabei por me perder.
                
                De dentro de um café surge um gnomo barrigudo, com um nariz grande e com chapéu pontiagudo quase maior que ele, que lhe diz:
                
                -olá viajante, a estrada principal fica por ali (apontando para o outro lado da floresta)... mas pode ficar por aqui mais um pouco, vejo que está cansada e faminta.
                
                Capuchinho então:
                
                Opções
                
                -muito obrigado, mas tenho que continuar o meu caminho (voltando a história principal, e ganhando um item no inventário: presente de um gnomo)
                
                -Pode ser, já estou com fome e já se bebia uma cervejinha fresquinha .
                
                Ao entrar no café, onde as mesas e as cadeiras são cogumelos gigantes, dão-lhe alguns tremoços e amendoins e a tão desejada cervejinha e passado pouco tempo começa a sentir-se muito cansada e com muito sono, percebe que está a ser dopada mas entretanto adormece.
                
                Quando acorda, Capuchinho está assustada sem saber onde está, mas olha em volta e percebe que está numa estrada muito parecida àquela para onde ela queria ir, e fica mais calma, pois pode partir em direção ao seu destino. Mas quando olha em volta percebe que já não tem o seu cesto, nem as suas novas Adidas. A pé e descalça e sem comida decide pôr-se a caminho.Após algumas horas, Capuchinho acaba por morrer de tanto andar e por não ter nenhuma comida.
                FIM DO JOGO
            )
            options:[1,2,3]
        },
        {
            id:1132 || 1232 || 1332,
            text:(Ao procurar por mais prendas, Capuchinho vai entrando cada vez mais dentro da floresta, até que encontra uma pequena vila de gnomos, com casas pequeninas e muito coloridas. Ela percebe que deve estar já muito longe do seu caminho, e decide perguntar por direções.
                -Olá, alguém me sabe dizer onde fica a estrada para o fim da vila principal? Eu estava a andar na floresta e acabei por me perder.
                De dentro de um café surge um gnomo barrigudo, com um nariz grande e com chapéu pontiagudo quase maior que ele, que lhe diz:
                -olá viajante, a estrada principal fica por ali (apontando para o outro lado da floresta)... mas pode ficar por aqui mais um pouco, vejo que está cansada e faminta.
                Capuchinho então;
                - 1. muito obrigado, mas tenho que continuar o meu caminho (voltando a história principal, e ganhando um item no inventário: presente de um gnomo)
                - 2. Pode ser, já estou com fome e já se bebia uma cervejinha fresquinha .
            )
            options:[1,2]
        },
        {
            id:11321 || 12321 || 13321,
            text:(Capuchinho segue as indicações do gnomo e rapidamente chega à estrada principal, após caminhar algum tempo Capuchinho Vermelho começa a ver ao longe a casa da sua avó. Quando chega à porta vê que esta está aberta, entra e vai em direção ao quarto. 
                Normalmente ela sentia-se muito feliz na casa de sua avózinha, mas naquele dia havia algo de estranho.
                – Avózinha, tens umas orelhas tão grandes! – exclamou Capuchinho Vermelho.
                – É para te ouvir melhor,minha netinha! – respondeu o lobo, disfarçando a voz.
                – Avózinha, tens uns olhos tão grandes!             
                – É para te ver melhor!              
                – Avozinha e que mãos  tão grandes!              
                – É para te abraçar melhor! – disse o lobo.              
                – Uau, avózinha, que boca tão grande! – exclamou a Capuchinho Vermelho.
               – É para te comer melhor!- gritou o lobo ao saltar da cama para fora e começou a perseguir o Capuchinho Vermelho pela floresta!               
                ali perto andava o caçador que tinha ajudado Capuchinho, ele começou a ouvir uns gritos que lhe pareciam familiares, agarrou na sua arma e machado e foi ver o que estava a acontecer. Ao ver a menina a fugir do lobo, decidiu montar uma armadilha e gritou ao Capuchinho que corresse em direção a ele. O lobo percebe-se de tudo e esconde-se na floresta. De repente ataca o caçador, mas este consegue desviar-se e o lobo acaba por cair na armadilha.                
                Capuchinho disse:
                – Obrigada, muito obrigada por me ajudar a livrar deste lobo louco! Agora precisamos de descobrir onde está a minha avózinha!
                
                O caçador prendeu o lobo numa jaula, obrigou-o a contar onde tinha escondido a senhora e ligou para a polícia da vila.
                
                Capuchinho e o caçador encontraram a avozinha, que nem tinha dado conta de nada. Os três foram então comer o bolo e as frutas que a Capuchinho tinha levado para a avózinha, felizes em saber que o lobo não voltaria a ser um perigo.
                
                Depois desse dia a Capuchinho decidiu nunca mais sair do seu caminho, ouvir com mais atenção o que a sua mãe tem a dizer e instalar o Cabify! 

                FIM DO JOGO
            )
            options:[1,2]
        },
        {
            id:11322 || 12322 || 13322,
            text:(Ao entrar no café, onde as mesas e as cadeiras são cogumelos gigantes, dão-lhe alguns tremoços e amendoins e a tão desejada cervejinha 
                e passado pouco tempo começa a sentir-se muito cansada e com muito sono, percebe que está a ser dopada mas entretanto adormece.
            
                Quando acorda, Capuchinho está assustada sem saber onde está, mas olha em volta e percebe que está numa estrada muito parecida 
                àquela para onde ela queria ir, e fica mais calma, pois pode partir em direção ao seu destino. Mas quando olha em volta percebe que já não
                 tem o seu cesto, nem as suas novas Adidas. A pé e descalça e sem comida decide pôr-se a caminho.Após algumas horas,
                  Capuchinho acaba por morrer de tanto andar e por não ter nenhuma comida.

                FIM DO JOGO
            )
            options:[1,2]
        },




        
    ])
}